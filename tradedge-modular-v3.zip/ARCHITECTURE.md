# TradEdge Modular Rebuild — Architecture

## File Structure
```
tradedge-journal/
├── index.html              ← Dashboard (lightweight, KPIs + open positions)
├── trades.html             ← Trade Log + Add/Edit modal
├── analytics.html          ← Charts, stats, heatmap, perf vs benchmark
├── calendar.html           ← Monthly P&L calendar
├── fund.html               ← Fund Management
├── ai.html                 ← AI Trade Review
├── news.html               ← News Intelligence
├── alerts.html             ← Price Alerts + GTT summary
├── ledger.html             ← Broker Ledger
├── possize.html            ← Position Sizing Calculator
├── execution.html          ← Trade Execution + GTT Orders
├── rrm-intel.html          ← RRM Position Intelligence + RRG chart
├── settings.html           ← All configs, broker sync, Supabase, Google Drive
├── autopilot.html          ← Edge Pilot (existing, gets sync wired)
├── matrix.html             ← MATRIX (existing)
├── mps.html                ← MPS Dashboard (existing)
│
├── css/
│   └── tradedge.css        ← All CSS (extracted from monolith)
│
├── js/
│   ├── core.js             ← trades[], save(), calc(), state, formatters
│   ├── supabase.js         ← Cloud sync with debounce + guards (FIXED)
│   ├── broker-sync.js      ← Dhan/Zerodha/Definedge sync engines
│   ├── symbols.js          ← NSE symbol DB + autocomplete engine
│   ├── live-prices.js      ← Yahoo Finance CMP fetcher
│   ├── ui.js               ← Sidebar, topbar, nav, toast, modals, theme
│   ├── charts.js           ← Chart.js helpers, equity curve, donut, bars
│   ├── trade-modal.js      ← Add/Edit trade form logic
│   ├── csv-import.js       ← CSV/XLSX import + smart merge
│   ├── ai-review.js        ← Claude/Gemini/Groq AI engines
│   ├── news-engine.js      ← RSS fetch + sentiment scoring
│   ├── alerts-engine.js    ← Price alerts + GTT local tracking
│   ├── execution.js        ← Order placement, positions, iceberg, bracket
│   ├── rrm-engine.js       ← Live JdK RS computation + transitions
│   ├── rrg-canvas.js       ← RRG chart rendering (Canvas 2D)
│   ├── fund-mgmt.js        ← Fund management table logic
│   └── journal-sync.js     ← Journal ↔ Edge Pilot bidirectional sync
│
├── data/                   ← (existing) rrm_data.json, mps_latest.json, etc.
└── scripts/                ← (existing) Python backend scripts
```

## Shared Core (loaded by ALL pages)
Every page includes:
```html
<link rel="stylesheet" href="css/tradedge.css">
<script src="js/core.js"></script>
<script src="js/supabase.js"></script>
<script src="js/ui.js"></script>
```

## Journal ↔ Edge Pilot Sync
- Shared localStorage key: `te_trades`
- Edge Pilot writes: `_epPyramid`, `_epSlMoves`, `_epRsTier`, etc.
- Journal reads EP fields and shows them in trade detail
- Both push to Supabase `tradedge_trades` table
- `journal-sync.js` handles:
  - StorageEvent listener (cross-tab sync)
  - Supabase realtime subscription (cross-device)
  - Conflict resolution: latest `updatedAt` wins
  - EP → Journal: new trades from Edge Pilot auto-appear
  - Journal → EP: SL/target changes reflect in EP pipeline
